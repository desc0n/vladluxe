<?php defined('SYSPATH') or die('No direct script access.');

class Kodoc_Method_Param extends Kohana_Kodoc_Method_Param {}
