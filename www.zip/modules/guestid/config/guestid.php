<?php defined('SYSPATH') OR die('No direct access allowed.');

return array
(

	"term" 		=> "Идентификация гостей",
	"expiration" => 2419200  // сколько хранить ID в куках .   (2419200 - месяц, 604800 - неделя )

);

?>