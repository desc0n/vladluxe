<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-07-21 16:47:30 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '?>' ~ APPPATH\views\header.php [ 5 ] in file:line
2016-07-21 16:47:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line