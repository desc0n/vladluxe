<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-10-07 15:18:05 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Admin::getCartNum() ~ APPPATH\classes\Controller\Ajax.php [ 63 ] in file:line
2016-10-07 15:18:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line