<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-10-08 13:04:18 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Admin::addToCart() ~ APPPATH\classes\Controller\Ajax.php [ 12 ] in file:line
2016-10-08 13:04:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-08 13:06:34 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: noticeId ~ APPPATH\classes\Controller\Ajax.php [ 10 ] in Z:\home\osnovnoi-instinct.lan\www\application\classes\Controller\Ajax.php:10
2016-10-08 13:06:34 --- DEBUG: #0 Z:\home\osnovnoi-instinct.lan\www\application\classes\Controller\Ajax.php(10): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\osnovno...', 10, Array)
#1 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_add_to_cart()
#2 [internal function]: Kohana_Controller->execute()
#3 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#6 Z:\home\osnovnoi-instinct.lan\www\index.php(119): Kohana_Request->execute()
#7 {main} in Z:\home\osnovnoi-instinct.lan\www\application\classes\Controller\Ajax.php:10
2016-10-08 13:20:22 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: rootPage ~ APPPATH\views\template.php [ 51 ] in Z:\home\osnovnoi-instinct.lan\www\application\views\template.php:51
2016-10-08 13:20:22 --- DEBUG: #0 Z:\home\osnovnoi-instinct.lan\www\application\views\template.php(51): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\osnovno...', 51, Array)
#1 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\osnovno...')
#2 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\osnovno...', Array)
#3 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 Z:\home\osnovnoi-instinct.lan\www\application\classes\Controller\Index.php(90): Kohana_Response->body(Object(View))
#6 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_cart()
#7 [internal function]: Kohana_Controller->execute()
#8 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#9 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 Z:\home\osnovnoi-instinct.lan\www\index.php(119): Kohana_Request->execute()
#12 {main} in Z:\home\osnovnoi-instinct.lan\www\application\views\template.php:51
2016-10-08 14:00:19 --- CRITICAL: ErrorException [ 2 ]: preg_replace(): Unknown modifier '+' ~ APPPATH\classes\Controller\Ajax.php [ 22 ] in file:line
2016-10-08 14:00:19 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'preg_replace():...', 'Z:\home\osnovno...', 22, Array)
#1 Z:\home\osnovnoi-instinct.lan\www\application\classes\Controller\Ajax.php(22): preg_replace('[\D]+', '', '2')
#2 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Controller.php(84): Controller_Ajax->action_set_cart_num()
#3 [internal function]: Kohana_Controller->execute()
#4 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#5 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#7 Z:\home\osnovnoi-instinct.lan\www\index.php(119): Kohana_Request->execute()
#8 {main} in file:line