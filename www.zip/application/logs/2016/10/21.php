<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-10-21 16:25:18 --- CRITICAL: Database_Exception [ 2 ]: mysql_connect(): Access denied for user 'cw87769_admin'@'localhost' (using password: YES) ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 67 ] in Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\MySQL.php:171
2016-10-21 16:25:18 --- DEBUG: #0 Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\MySQL.php(171): Kohana_Database_MySQL->connect()
#1 Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQL->query(3, 'SET time_zone =...', false, Array)
#2 Z:\home\vladlux.lan\www\application\classes\Model\Admin.php(18): Kohana_Database_Query->execute()
#3 Z:\home\vladlux.lan\www\system\classes\Kohana\Model.php(26): Model_Admin->__construct()
#4 Z:\home\vladlux.lan\www\application\classes\Controller\Base.php(12): Kohana_Model::factory('Admin')
#5 Z:\home\vladlux.lan\www\system\classes\Kohana\Controller.php(69): Controller_Base->before()
#6 [internal function]: Kohana_Controller->execute()
#7 Z:\home\vladlux.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#8 Z:\home\vladlux.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 Z:\home\vladlux.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#10 Z:\home\vladlux.lan\www\index.php(119): Kohana_Request->execute()
#11 {main} in Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\MySQL.php:171
2016-10-21 16:26:33 --- CRITICAL: Database_Exception [ 1146 ]: Table 'cw87769_main.guests' doesn't exist [ INSERT INTO `guests` (`date`) VALUES (NOW()) ] ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 194 ] in Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\Query.php:251
2016-10-21 16:26:33 --- DEBUG: #0 Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQL->query(2, 'INSERT INTO `gu...', false, Array)
#1 Z:\home\vladlux.lan\www\application\classes\Model\Admin.php(559): Kohana_Database_Query->execute()
#2 Z:\home\vladlux.lan\www\application\classes\Controller\Base.php(17): Model_Admin->setGuestId()
#3 Z:\home\vladlux.lan\www\system\classes\Kohana\Controller.php(69): Controller_Base->before()
#4 [internal function]: Kohana_Controller->execute()
#5 Z:\home\vladlux.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#6 Z:\home\vladlux.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 Z:\home\vladlux.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#8 Z:\home\vladlux.lan\www\index.php(119): Kohana_Request->execute()
#9 {main} in Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\Query.php:251
2016-10-21 16:29:36 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'p.slug' in 'field list' [ SELECT `m`.*, `p`.`title` AS `name`, `p`.`slug` FROM `menu` AS `m` JOIN `pages` AS `p` ON (`p`.`id` = `m`.`page_id`) WHERE `m`.`parent_id` IS NULL AND `m`.`status_id` = 1 ] ~ MODPATH\database\classes\Kohana\Database\MySQL.php [ 194 ] in Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\Query.php:251
2016-10-21 16:29:36 --- DEBUG: #0 Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQL->query(1, 'SELECT `m`.*, `...', false, Array)
#1 Z:\home\vladlux.lan\www\application\classes\Model\Content.php(66): Kohana_Database_Query->execute()
#2 Z:\home\vladlux.lan\www\application\classes\Model\Content.php(14): Model_Content->getMenu()
#3 Z:\home\vladlux.lan\www\application\classes\Controller\Index.php(16): Model_Content->getBaseTemplate()
#4 Z:\home\vladlux.lan\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 Z:\home\vladlux.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#7 Z:\home\vladlux.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 Z:\home\vladlux.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#9 Z:\home\vladlux.lan\www\index.php(119): Kohana_Request->execute()
#10 {main} in Z:\home\vladlux.lan\www\modules\database\classes\Kohana\Database\Query.php:251