<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-08-01 16:24:33 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: slug ~ APPPATH\views\header.php [ 5 ] in Z:\home\osnovnoi-instinct.lan\www\application\views\header.php:5
2016-08-01 16:24:33 --- DEBUG: #0 Z:\home\osnovnoi-instinct.lan\www\application\views\header.php(5): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\osnovno...', 5, Array)
#1 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\osnovno...')
#2 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\osnovno...', Array)
#3 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\osnovnoi-instinct.lan\www\application\views\template.php(29): Kohana_View->__toString()
#5 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\osnovno...')
#6 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\osnovno...', Array)
#7 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#8 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#9 Z:\home\osnovnoi-instinct.lan\www\application\classes\Controller\Index.php(17): Kohana_Response->body(Object(View))
#10 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Controller.php(84): Controller_Index->action_index()
#11 [internal function]: Kohana_Controller->execute()
#12 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index))
#13 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#14 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#15 Z:\home\osnovnoi-instinct.lan\www\index.php(119): Kohana_Request->execute()
#16 {main} in Z:\home\osnovnoi-instinct.lan\www\application\views\header.php:5
2016-08-01 16:26:03 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: rootPage ~ APPPATH\views\template.php [ 28 ] in Z:\home\osnovnoi-instinct.lan\www\application\views\template.php:28
2016-08-01 16:26:03 --- DEBUG: #0 Z:\home\osnovnoi-instinct.lan\www\application\views\template.php(28): Kohana_Core::error_handler(8, 'Undefined varia...', 'Z:\home\osnovno...', 28, Array)
#1 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(61): include('Z:\home\osnovno...')
#2 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(348): Kohana_View::capture('Z:\home\osnovno...', Array)
#3 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\View.php(228): Kohana_View->render()
#4 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 Z:\home\osnovnoi-instinct.lan\www\application\classes\Controller\Item.php(33): Kohana_Response->body(Object(View))
#6 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Controller.php(84): Controller_Item->action_show()
#7 [internal function]: Kohana_Controller->execute()
#8 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Item))
#9 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 Z:\home\osnovnoi-instinct.lan\www\system\classes\Kohana\Request.php(990): Kohana_Request_Client->execute(Object(Request))
#11 Z:\home\osnovnoi-instinct.lan\www\index.php(119): Kohana_Request->execute()
#12 {main} in Z:\home\osnovnoi-instinct.lan\www\application\views\template.php:28